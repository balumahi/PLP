package com.cg.hbms.service;

import java.util.List;

import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.dto.RoomDetails;
import com.cg.hbms.dto.Users;
import com.cg.hbms.exception.HotelException;

public interface IHbmsService
{
	public int addHotel(Hotels hotel) ;
	
	public int addUser(Users user) ;
	
	public int addRoom(RoomDetails room) ;

	public int addBooking(BookingDetails book);

	public List<Hotels> showHotels();

	public List<RoomDetails> showRooms();

	public List<Users> showUsers();

	public List<BookingDetails> showBookings();

	public List<Hotels> searchHotels(String city);
	
	public List<BookingDetails> viewMyBooking(int userId);

	public List<RoomDetails> searchRooms(String roomType);
	
	public List<Users> searchUsers(int userId);

	public void removeHotel(int hotelId);

	public void removeRoom(int roomId);
	
	public void removeBooking(int bookingId);
	
	public void updateHotel(Hotels hotel);

	public Hotels searchHotelsId(int id);

	public RoomDetails searchRoomsId(int id);

	public void updateRoom(RoomDetails room);

	public String getRole(String name, String pass);
	
	public Users getUser(String name);
	public void changePassword(Users user) throws HotelException;

	
}
