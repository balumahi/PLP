package com.cg.hbms.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="USER_HBMS")
public class Users 
{
		@Id
		@Column(name="USER_ID")
		@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="userid")
		@SequenceGenerator(name="userid", sequenceName="USER_HBMS_SEQ")
		private Integer userId;
		
		@Column(name="PASSWORD")
		private String password;
		
		@Column(name="ROLE")
		private String role;
		
		@Column(name="USER_NAME")
		private String userName;
		
		@Column(name="MOBILE_NO")
		private String mobileNumber;
		
		@Column(name="PHONE")
		private String phoneNumber;
		
		@Column(name="ADDRESS")
		private String address;
		
		@Column(name="EMAIL")
		private String email;

		public Integer getUserId() {
			return userId;
		}

		public void setUserId(Integer userId) {
			this.userId = userId;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		public String getRole() {
			return role;
		}

		public void setRole(String role) {
			this.role = role;
		}

		public String getUserName() {
			return userName;
		}

		public void setUserName(String userName) {
			this.userName = userName;
		}

		public String getMobileNumber() {
			return mobileNumber;
		}

		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}

		public String getPhoneNumber() {
			return phoneNumber;
		}

		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		@Override
		public String toString() {
			return "Users [userId=" + userId + ", password=" + password + ", role="
					+ role + ", userName=" + userName + ", mobileNumber="
					+ mobileNumber + ", phoneNumber=" + phoneNumber + ", address="
					+ address + ", email=" + email + "]";
		}
}
