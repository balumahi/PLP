package com.cg.hbms.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="ROOM_HBMS")
public class RoomDetails 
{	

	@Column(name="HOTEL_ID")
	private int hotelId;  
	
	@Id
	@Column(name="ROOM_ID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="roomid")
	@SequenceGenerator(name="roomid", sequenceName="ROOM_HBMS_SEQ")
	private int roomId;  
	
	@Column(name="ROOM_NO")

	private String roomNo;
	
	@Column(name="ROOM_TYPE")
	private String roomType;
	
	@Column(name="PER_NIGHT_RATE")
	
	private String perNightRate;
	
	@Column(name="AVAILABILITY")
	private Boolean availability;

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public String getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public String getPerNightRate() {
		return perNightRate;
	}

	public void setPerNightRate(String perNightRate) {
		this.perNightRate = perNightRate;
	}

	public Boolean getAvailability() {
		return availability;
	}

	public void setAvailability(Boolean availability) {
		this.availability = availability;
	}

	@Override
	public String toString() {
		return "RoomDetails [hotelId=" + hotelId + ", roomId=" + roomId
				+ ", roomNo=" + roomNo + ", roomType=" + roomType
				+ ", perNightRate=" + perNightRate + ", availability="
				+ availability + "]";
	}
	
	
	
}
